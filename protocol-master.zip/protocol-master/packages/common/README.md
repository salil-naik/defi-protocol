# @uma/common

This package contains common javascript utilities and files used by other `@uma` packages. It is rarely used outside of
that context.

## Installing the package

```bash
yarn add @uma/common
```

## Importing the package

```js
// One of many possible possible functions to import.
{ getTruffleConfig } = require("@uma/core");
```
