# Payouts

This folder contains a history of payouts for UMA incentive programs: Dev Mining and Dapp Mining.

# Dev Mining

Dev mining rewards are in the dev mining folder. The current state of dev mining will be updated
weekly in devmining-status.json. In here you can get the current total UMA rewards per week
as well as the whitelisted EMP contracts eligible to receive rewards.
