module.exports = {
  ...require("./src/ServerlessHub"),
  ...require("./src/ServerlessSpoke")
};
